MESH KIT: LDRAW + LPUB3D EDITION
XIAO ESP32S3 and Wio-SX1262
Created 2026-10-19

The assembly guide is authored as native LDraw geometry and LPub3D page
commands. LPub3D 2.4.9 r86 for Apple Silicon produced the PDF and the four
PNG pages. No AI image generation, raster tracing, browser rendering, or
external page-layout engine was used for those pages.

OPEN AND EDIT

Open mesh-kit.mpd in LPub3D. It includes every custom DAT part inline.
Choose the Native renderer. Four ordinary STEP boundaries create the four
instruction pages. CLEAR resets the displayed scene between pages.

The parts folder contains the same editable geometry as individual DAT
files. The MPD and DAT files are plain text. The output folder contains:

  mesh-kit-lpub3d.pdf           Four 16:9 instruction pages
  pages/                      Four direct LPub3D PNG exports, 2000 x 1125
  mesh-kit-assembly-sheet.png  The four exported pages in a 2 x 2 sheet
  mesh-kit-preview.png         A smaller preview of that sheet
  mesh-kit-ldraw-source.zip    Portable source and output package

OFFICIAL MODELS

Both source STEP files are preserved in source-models. Their hashes are
recorded in parts/boards-manifest.json. These are the official Seeed board
models, tessellated into native 3D triangles. Black outlines follow original
CAD feature curves. Triangle tessellation seams are not drawn.

XIAO source:
https://files.seeedstudio.com/wiki/SeeedStudio-XIAO-ESP32S3/res/seeed-studio-xiao-esp32s3-3d_model.zip

Wio source:
https://files.seeedstudio.com/products/SenseCAP/Wio_SX1262/Wio-SX1262_for_XIAO_3D_file.step

Kit reference:
https://wiki.seeedstudio.com/wio_sx1262_with_xiao_esp32s3_kit/

Wi-Fi antenna reference:
https://files.seeedstudio.com/wiki/XIAO_WiFi/antenna/FPC_Antenna_2.4GHz_1.16dbi_for_XIAO_ESP32S3/res/Datasheet_2.4GHz_FPC_Antenna_1.16dbi_for_XIAO_ESP32S3.pdf

LoRa antenna comparison:
https://files.seeedstudio.com/wiki/XIAO_ESP32S3_for_Meshtastic_LoRa/37.png

LDraw format:
https://www.ldraw.org/article/218.html

LPub3D:
https://trevorsandy.github.io/lpub3d/

WHAT WAS ADDED

The official STEP files omit the antennas, XIAO populated B2B socket,
installed XIAO headers, and Wio pushbutton. Those are separate procedural
parts, not manufacturer CAD. The supplied photos and manufacturer references
establish their arrangement. Antenna outlines are 37.4 x 17.5 mm for Wi-Fi
and 40 x 7 mm for LoRa. Cable bends, thin-sheet thickness, plug caps, header
depths, and the added B2B socket are simplified for instruction clarity.

The normalized CAD axes are X across the PCB, Y from USB toward its rear
antenna edge, and Z upward. One millimeter becomes 2.5 LDraw units with
the mapping (X, Y, Z) -> 2.5 * (X, -Z, Y).

Wio sits above XIAO with both shields facing up. The joined scene uses a
nominal Wio PCB offset of 5 mm, not a measured enclosure-design datum.
Official STEP bodies have zero intersection at this offset. The added
schematic XIAO socket overlaps the Wio connector internally, so the
supplemental contact geometry is not a mechanical fit validation.

REBUILD THE GUIDE

With LPub3D installed:

  python3 scripts/export_lpub3d.py

On another platform, pass --lpub3d /path/to/executable or set LPUB3D_BIN.
Set LDRAWDIR to an extracted LDraw library. On macOS, the script can extract
the library included in the installed LPub3D application into library/.
It uses only the Native renderer, so LDView and POV-Ray are not required.

To regenerate the STEP conversions:

  python3 -m venv .venv
  .venv/bin/pip install cadquery-ocp==7.9.3.1.1
  .venv/bin/python scripts/convert_boards.py
  python3 scripts/export_lpub3d.py

The supplementary definition snapshot is retained in source-models for
provenance. Its geometry definitions are implemented directly in the
converter, so no earlier edition is needed.

To validate and package the exports:

  python3 -m pip install Pillow pypdf
  python3 scripts/package_outputs.py

LPUB3D DETAILS

The MPD uses custom Unofficial_Part sections to keep the native board
geometry intact, rather than treating each electronic component as a build
step. Automatic LEGO parts lists are disabled because the four instruction
scenes are independent illustrated stages.

Arrows are native LDraw helper geometry. LPub3D's INSERT ARROW parser exists
in this release, but its page-rendering branch does not draw an arrow.

The export wrapper checks CameraProjection in the actual renderer log.
LPub3D 2.4.9 sometimes needs a fresh process after setting the orthographic
preference, so the wrapper retries that startup transition when needed.
Named cameras were avoided because that route crashed this macOS build.

The PDF contains LPub3D's rendered 3D images and native PDF text. It is not
an all-vector CAD drawing. The editable 3D source is the MPD/DAT project.

VALIDATION

All four final pages were rendered and visually checked for clipping,
overlaps, antenna routing, socket placement, board orientation, and stacking.
An independent review checked the source geometry and the final page images.
research/validation.json records file integrity and export checks.

This is an unofficial assembly guide. Manufacturer source geometry retains
its original ownership. It is not an official LDraw library part release.
